#include "gui_forms/window.hpp"
#include "table.hpp"
#include <cstdlib>
#include <filesystem>
#include <iostream>
#include <stdexcept>
#include <unistd.h>
namespace gf = gui_forms;
void require(bool condition, const char* message) {
    if (!condition)
        throw std::runtime_error(message);
}
void pointer(gf::Window& window, gf::PointerAction action, gf::Point point) {
    gf::PointerEvent event;
    event.action = action;
    event.button = gf::PointerButton::primary;
    event.position = point;
    static_cast<void>(window.dispatch_pointer(event));
}
int main() {
    std::filesystem::path scratch =
        std::filesystem::temp_directory_path() / ("games-ui-test-" + std::to_string(getpid()));
    setenv("GAMES_STATE_DIR", scratch.c_str(), 1);
    std::shared_ptr<games::Table> table =
        gf::make_control<games::Table>(gf::StableId("test.table"));
    (*table).game.deal(games::Kind::freecell, 42);
    std::unique_ptr<gf::Window> window = std::make_unique<gf::Window>(table, gf::Size{1180, 800});
    (*window).perform_layout();
    // The exposed card in column zero goes to the first empty free cell.
    int id = (*table).game.state.piles[0].back().id;
    pointer(*window, gf::PointerAction::down, {80, 500});
    pointer(*window, gf::PointerAction::move, {80, 180});
    pointer(*window, gf::PointerAction::up, {80, 180});
    require((*table).game.state.piles[16].size() == 1, "native routing: drop onto free cell");
    require((*table).game.state.piles[16].back().id == id, "native routing: correct dragged card");
    require((*table).game.state.moves == 1, "native routing: exactly one move");
    require(!(*table).has_pointer_capture(), "native routing: released pointer capture");
    require((*table).game.invariant(), "native routing: conservation");
    require((*table).game.undo(), "native routing: undo");
    require((*window).request_focus(table), "keyboard table focus");
    int before_moves = (*table).game.state.moves;
    require((*table).game.hint().from >= 0, "keyboard fixture has hint");
    static_cast<void>((*window).dispatch_key({gf::KeyAction::down, gf::PhysicalKey::h}));
    static_cast<void>((*window).dispatch_key({gf::KeyAction::down, gf::PhysicalKey::enter}));
    require((*table).game.state.moves == before_moves + 1,
            "keyboard H and Enter commits suggested legal move");
    (*table).game.deal(games::Kind::solitaire, 42);
    (*table).arrange({0, 0, 1180, 800});
    std::size_t stock = (*table).game.state.piles[14].size();
    pointer(*window, gf::PointerAction::down, {100, 160});
    pointer(*window, gf::PointerAction::up, {100, 160});
    require((*table).game.state.piles[14].size() + 1 == stock, "native routing: draw stock");
    // Route a real last move through the UI, then record a named score exactly once.
    (*table).game.deal(games::Kind::freecell, 99);
    for (games::Pile& pile : (*table).game.state.piles)
        pile.clear();
    for (int suit = 0; suit < 4; ++suit)
        for (int rank = 1; rank <= 13; ++rank) {
            games::Card card{rank, suit, suit * 13 + rank - 1, true};
            (*table).game.state.piles[suit == 3 && rank == 13 ? 0 : 10 + suit].push_back(card);
        }
    (*table).arrange({0, 0, 1180, 800});
    static_cast<void>((*window).request_focus(table));
    static_cast<void>((*window).dispatch_key({gf::KeyAction::down, gf::PhysicalKey::h}));
    static_cast<void>((*window).dispatch_key({gf::KeyAction::down, gf::PhysicalKey::enter}));
    require((*table).game.state.over, "last legal move finishes the game");
    std::shared_ptr<gf::TextBox> name;
    for (const std::shared_ptr<gf::Control>& child : (*table).children())
        if ((*child).stable_id().value() == "score.name")
            name = std::dynamic_pointer_cast<gf::TextBox>(child);
    require(name && (*name).visible(), "completion opens named score entry");
    (*name).set_text("Routing Ace");
    pointer(*window, gf::PointerAction::down, {600, 254});
    pointer(*window, gf::PointerAction::up, {600, 254});
    games::Cabinet saved;
    require(games::load_cabinet(games::cabinet_path(), saved), "completed game autosaved");
    require(saved.result_recorded[2] && saved.top_scores[5].size() == 1 &&
                saved.top_scores[5][0].name == "Routing Ace",
            "named score saved");
    require(!(*name).visible(), "entry closes after submission");
    // Repeated clicks cannot create a duplicate score.
    pointer(*window, gf::PointerAction::down, {600, 254});
    pointer(*window, gf::PointerAction::up, {600, 254});
    require(games::load_cabinet(games::cabinet_path(), saved) && saved.top_scores[5].size() == 1,
            "duplicate score prevented");
    // New game from the result window immediately replaces the saved active table.
    pointer(*window, gf::PointerAction::down, {837, 597});
    pointer(*window, gf::PointerAction::up, {837, 597});
    require(games::load_cabinet(games::cabinet_path(), saved) && !saved.games[2].state.over &&
                !saved.result_recorded[2] && saved.games[2].state.seed != 99,
            "new game immediately saved; result latch reset");
    window.reset();
    table.reset();
    std::filesystem::remove_all(scratch);
    std::cout << "Passed: GUI.Forms routed drag/drop, capture release, stock click, conservation "
                 "and undo.\n";
}
