#include "puzzle_view.hpp"
#include "audio.hpp"
#include "gui_forms/window.hpp"
#include "presentation.hpp"
#include "storage.hpp"
#include <algorithm>
#include <cmath>
#include <fstream>
namespace games {
static const gf::Color ink = gf::Color::rgba(231, 238, 247), muted = gf::Color::rgba(154, 177, 198),
                       accent = gf::Color::rgba(119, 216, 229);
static gf::Color peg_color(int n) {
    const gf::Color colors[] = {gf::Color::rgba(47, 60, 79),    gf::Color::rgba(228, 72, 102),
                                gf::Color::rgba(67, 175, 244),  gf::Color::rgba(246, 189, 70),
                                gf::Color::rgba(113, 211, 137), gf::Color::rgba(167, 121, 237),
                                gf::Color::rgba(71, 211, 197)};
    return colors[std::clamp(n, 0, 6)];
}
static bool in_rect(gf::Rect r, gf::Point p) {
    return p.x >= r.x && p.y >= r.y && p.x < r.x + r.width && p.y < r.y + r.height;
}
static gf::ImageId load_art(gf::Window& window, const std::string& name) {
    std::ifstream file(asset_directory() + "/" + name, std::ios::binary | std::ios::ate);
    if (!file)
        return {};
    std::streamsize size = file.tellg();
    file.seekg(0);
    std::vector<std::byte> bytes(static_cast<std::size_t>(size));
    file.read(reinterpret_cast<char*>(bytes.data()), size);
    gf::ImageLoadResult result = window.load_png(bytes);
    return result ? result.image : gf::ImageId{};
}
PuzzleView::PuzzleView(gf::StableId id, PuzzleKind kind) : Control(std::move(id)), game(kind) {
    set_focusable(true);
    set_accessible_name(puzzle_title(kind));
    if (!game.load(path()))
        game.deal(static_cast<std::uint32_t>(
            std::chrono::system_clock::now().time_since_epoch().count()));
}
std::filesystem::path PuzzleView::path() const {
    return cabinet_path().parent_path() / (std::string(puzzle_slug(game.kind)) + "-v1.txt");
}
void PuzzleView::initialize_control_tree() {
    const char* labels[] = {"New game", "Help",  "Top scores", "Submit",  "Rotate",
                            "Flip",     "Close", "Save name",  "New game"};
    for (int i = 0; i < 9; ++i) {
        buttons_[i] = gf::make_control<GameButton>(
            gf::StableId(std::string(puzzle_slug(game.kind)) + ".action." + std::to_string(i)),
            labels[i]);
        add_child(buttons_[i]);
        subscriptions_.push_back(
            (*buttons_[i])
                .clicked()
                .subscribe(
                    *this,
                    gf::Delegate<gf::ButtonBase&>::bind<PuzzleView, &PuzzleView::action>(*this)));
        (*buttons_[i])
            .set_visible(
                i < 3 ||
                (i == 3 && (game.kind == PuzzleKind::pegs || game.kind == PuzzleKind::atom)) ||
                ((i == 4 || i == 5) && game.kind == PuzzleKind::solve));
    }
    name_ = gf::make_control<gf::TextBox>(
        gf::StableId(std::string(puzzle_slug(game.kind)) + ".name"), game.player_name);
    (*name_).set_maximum_length(24);
    (*name_).set_accessible_name("Your name for the top scores");
    (*name_).set_visible(false);
    add_child(name_);
}
void PuzzleView::on_attached_to_window() {
    timer_ = std::make_unique<gf::Timer>(*attached_window(), std::chrono::milliseconds(16));
    subscriptions_.push_back((*timer_).tick().subscribe(
        *this, gf::Delegate<>::bind<PuzzleView, &PuzzleView::tick>(*this)));
    if (game.kind == PuzzleKind::cube) {
        nature_ = load_art(*attached_window(), "nature-lake.png");
        raster_.load_environment(asset_directory() + "/nature-lake.png");
    }
    if (game.kind == PuzzleKind::switches)
        girl_ = load_art(*attached_window(), "switchbox-girl.png");
    for (int i = 0; i < 4; ++i)
        guess_[i] = game.state.marks[i];
    clock_start_ = gf::FrameClock::now();
}
void PuzzleView::on_detaching_from_window(gf::Window& window) noexcept {
    persist();
    if (timer_)
        (*timer_).stop();
    timer_.reset();
    for (gf::ImageId id : {image_, nature_, girl_})
        if (id.value)
            static_cast<void>(window.remove_image(id));
}
void PuzzleView::activate() {
    Cabinet preferences;
    if (load_cabinet(cabinet_path(), preferences)) {
        sound_ = preferences.sound;
        music_ = preferences.music;
        reduced_ = preferences.reduced;
    }
    music_play(game.kind == PuzzleKind::cube ? "nature_cube" : puzzle_slug(game.kind), music_);
    persist();
    if (game.state.over && !game.recorded)
        panel(2);
    if (attached_window())
        static_cast<void>((*attached_window()).request_focus(shared_from_this()));
    if (game.kind == PuzzleKind::gems && !reduced_ && timer_)
        (*timer_).start();
    render();
    invalidate(gf::Dirty::paint);
}
void PuzzleView::arrange(gf::Rect b) {
    arrange_self(b);
    set_child_layout(buttons_[0], {b.width - 367, 18, 108, 34});
    set_child_layout(buttons_[1], {b.width - 247, 18, 80, 34});
    set_child_layout(buttons_[2], {b.width - 155, 18, 128, 34});
    double reserve = game.kind == PuzzleKind::solve                                   ? 496.0
                     : game.kind == PuzzleKind::pegs || game.kind == PuzzleKind::atom ? 424.0
                                                                                      : 300.0;
    double side = std::min({548.0, b.height - 155, b.width - reserve});
    board_ = {std::max(248.0, (b.width - side) * .5), 86, side, side};
    set_child_layout(buttons_[3],
                     {board_.x + board_.width + 37, board_.y + board_.height - 45, 128, 35});
    set_child_layout(buttons_[4],
                     {board_.x + board_.width + 26, board_.y + board_.height - 88, 87, 34});
    set_child_layout(buttons_[5],
                     {board_.x + board_.width + 122, board_.y + board_.height - 88, 77, 34});
    popup_ = {b.width * .5 - 320, 86, 640, std::min(530.0, b.height - 103)};
    set_child_layout(buttons_[6], {popup_.x + 530, popup_.y + 17, 85, 32});
    set_child_layout(name_, {popup_.x + 28, popup_.y + 110, 270, 34});
    set_child_layout(buttons_[7], {popup_.x + 310, popup_.y + 110, 110, 34});
    set_child_layout(buttons_[8], {popup_.x + 490, popup_.y + popup_.height - 45, 122, 32});
    if (game.kind == PuzzleKind::gems || game.kind == PuzzleKind::cube) {
        int w = static_cast<int>(board_.width * 1.5), h = static_cast<int>(board_.height * 1.5);
        if (raster_.width != w || raster_.height != h)
            raster_.resize(w, h);
        render();
    }
}
void PuzzleView::text(gf::Painter& p, double x, double y, const std::string& s, double size,
                      gf::Color c) {
    p.draw_text_utf8({x, y}, s,
                     {size >= 18 ? gf::FontRole::control : gf::FontRole::content, size,
                      static_cast<std::uint16_t>(size >= 18 ? 600 : 400), false},
                     c);
}
double PuzzleView::elapsed() const {
    return std::chrono::duration<double>(gf::FrameClock::now() - animation_start_).count();
}
void PuzzleView::render() {
    if (!attached_window() || raster_.width <= 1)
        return;
    if (game.kind == PuzzleKind::cube)
        raster_.cube(game, yaw_, pitch_, hover_);
    else if (game.kind == PuzzleKind::gems) {
        raster_.clear();
        double time = std::chrono::duration<double>(gf::FrameClock::now() - clock_start_).count();
        double cell = raster_.width / 8.0;
        double t = elapsed();
        bool moving = animation_duration_ > 0 && t < animation_duration_;
        const std::array<int, 96>* grid = &game.state.grid;
        const std::array<int, 96>* source = nullptr;
        bool falling = false;
        double progress = 1;
        std::array<int, 64> origin{};
        if (moving) {
            if (t < .23 || invalid_swap_)
                grid = &before_swap_;
            else if (game.cascade_frames.size() > 1) {
                double frame_time = (t - .23) / .24;
                int step = std::clamp(static_cast<int>(frame_time), 0,
                                      static_cast<int>(game.cascade_frames.size()) - 2);
                progress = std::clamp(frame_time - step, 0.0, 1.0);
                source = &game.cascade_frames[step];
                grid = &game.cascade_frames[step + 1];
                falling = (step % 2) == 1;
                if (falling)
                    for (int x = 0; x < 8; ++x) {
                        int dest = 7;
                        for (int row = 7; row >= 0; --row)
                            if ((*source)[row * 8 + x])
                                origin[dest-- * 8 + x] = row;
                        int missing = dest + 1;
                        while (dest >= 0) {
                            origin[dest * 8 + x] = dest - missing;
                            --dest;
                        }
                    }
            }
        }
        for (int i = 0; i < 64; ++i) {
            int value = (*grid)[i];
            double radius = cell * .38;
            double x = (i % 8 + .5) * cell, y = (i / 8 + .5) * cell;
            if (source && !falling && (*source)[i] != value) {
                if (progress < .5) {
                    value = (*source)[i];
                    radius *= 1 - progress * 1.7;
                } else
                    radius *= .15 + (progress - .5) * 1.7;
            }
            if (!value || radius < .5)
                continue;
            if (falling) {
                double ease = 1 - std::pow(1 - progress, 3);
                y = (origin[i] + (i / 8 - origin[i]) * ease + .5) * cell;
            }
            if (moving && (i == swap_a_ || i == swap_b_) && (t < .23 || invalid_swap_)) {
                double u = std::clamp(t / .23, 0.0, 1.0);
                if (invalid_swap_ && t > .23)
                    u = 1 - std::clamp((t - .23) / .23, 0.0, 1.0);
                u = u * u * (3 - 2 * u);
                int other = i == swap_a_ ? swap_b_ : swap_a_;
                x += (other % 8 - i % 8) * cell * u;
                y += (other / 8 - i / 8) * cell * u;
            }
            double spin = hover_ == i && !reduced_ ? time * 2.1 : 0,
                   glisten = reduced_ ? 0 : .5 + .5 * std::sin(time * 1.25 + i * 2.7);
            raster_.gem({x, y}, radius, value, spin, glisten, i);
        }
    } else
        return;
    gf::ImageLoadResult result =
        image_.value ? (*attached_window())
                           .update_bgra32_premultiplied(image_, raster_.width, raster_.height,
                                                        raster_.width * 4, raster_.pixels, *this)
                     : (*attached_window())
                           .load_bgra32_premultiplied(raster_.width, raster_.height,
                                                      raster_.width * 4, raster_.pixels);
    if (result)
        image_ = result.image;
}
void PuzzleView::paint_gems(gf::Painter& p) {
    p.draw_box_shadow(board_, 16, {0, 8}, 24, 0, gf::Color::rgba(0, 0, 0, 100));
    p.fill_rounded_rect(board_, 16, gf::Color::rgba(12, 22, 42));
    double cell = board_.width / 8;
    for (int i = 0; i < 64; ++i)
        if ((i / 8 + i % 8) % 2 == 0)
            p.fill_rounded_rect(
                {board_.x + (i % 8) * cell + 2, board_.y + (i / 8) * cell + 2, cell - 4, cell - 4},
                7, gf::Color::rgba(26, 41, 63));
    if (image_.value)
        p.draw_image(image_, board_);
    text(p, 28, 113, "Match & cascade", 19, accent);
    text(p, 28, 146, "Drag to swap neighbors.", 13, ink);
    text(p, 28, 172, "Match 3 or more.", 13, muted);
    text(p, 28, 222, "4 in a line → bomb", 13, ink);
    text(p, 28, 250, "5 in a line → hypercube", 13, ink);
    text(p, 28, 278, "T or L → star", 13, ink);
    text(p, 28, 328, "Match bombs and stars", 13, muted);
    text(p, 28, 351, "with their own color.", 13, muted);
    text(p, 28, 398, std::to_string(game.gem_colors()) + " colors in play", 14, accent);
}
void PuzzleView::paint_untangle(gf::Painter& p) {
    std::vector<Point2> positions = game.state.nodes;
    if (drag_ >= 0)
        positions[drag_] = drag_position_;
    for (Edge e : game.state.edges) {
        Point2 a = positions[e.a], b = positions[e.b];
        p.draw_line({board_.x + a.x * board_.width, board_.y + a.y * board_.height},
                    {board_.x + b.x * board_.width, board_.y + b.y * board_.height},
                    gf::Color::rgba(112, 193, 214, 190), 2.3);
    }
    for (int i = 0; i < 12; ++i) {
        Point2 q = positions[i];
        gf::Rect r{board_.x + q.x * board_.width - 14, board_.y + q.y * board_.height - 14, 28, 28};
        p.draw_box_shadow(r, 14, {0, 3}, 10, 0, gf::Color::rgba(0, 0, 0, 100));
        p.fill_rounded_rect(
            r, 14, i == drag_ ? gf::Color::rgba(248, 210, 133) : gf::Color::rgba(183, 231, 226));
        p.stroke_rounded_rect(r, 14, gf::Color::rgba(75, 137, 153), 2);
        text(p, r.x + (i < 9 ? 10 : 6), r.y + 19, std::to_string(i + 1), 11,
             gf::Color::rgba(32, 67, 80));
    }
    text(p, 28, 119, "Untie the lines", 18, accent);
    text(p, 28, 157, "Drag the pearl points.", 13, ink);
    text(p, 28, 184, "No lines may cross.", 13, ink);
    text(p, 28, 235, "Points need their", 13, muted);
    text(p, 28, 258, "own breathing space.", 13, muted);
}
void PuzzleView::paint_pegs(gf::Painter& p) {
    cells_.clear();
    double row = board_.height / 11;
    double x = board_.x + 65;
    for (int attempt = 0; attempt < 10; ++attempt) {
        double y = board_.y + attempt * row;
        p.fill_rounded_rect({board_.x + 12, y + 2, board_.width - 24, row - 4}, 8,
                            attempt == game.state.stage ? gf::Color::rgba(39, 67, 85)
                                                        : gf::Color::rgba(27, 42, 59));
        text(p, board_.x + 28, y + row * .65, std::to_string(attempt + 1), 13, muted);
        for (int j = 0; j < 4; ++j) {
            int value = attempt < game.state.stage    ? game.state.grid[attempt * 4 + j]
                        : attempt == game.state.stage ? guess_[j]
                                                      : 0;
            gf::Rect r{x + j * 58, y + 6, row - 12, row - 12};
            p.fill_rounded_rect(r, r.width * .5, peg_color(value));
            if (value)
                text(p, r.x + r.width * .34, r.y + r.height * .72,
                     std::string(1, static_cast<char>('A' + value - 1)), r.height * .48,
                     gf::Color::rgba(16, 29, 45));
            if (attempt == game.state.stage) {
                cells_.push_back(r);
                if (j == selection_)
                    p.stroke_rounded_rect({r.x - 3, r.y - 3, r.width + 6, r.height + 6},
                                          r.width * .5, accent, 2);
            }
        }
        if (attempt < game.state.stage) {
            for (int j = 0; j < 4; ++j) {
                gf::Rect r{board_.x + board_.width - 119 + j * 24, y + row * .5 - 6, 12, 12};
                if (j < game.state.aux[attempt * 2])
                    p.fill_rounded_rect(r, 6, ink);
                else if (j < game.state.aux[attempt * 2] + game.state.aux[attempt * 2 + 1])
                    p.stroke_rounded_rect(r, 6, ink, 2);
            }
        }
    }
    double px = board_.x + board_.width + 52;
    for (int i = 1; i <= 6; ++i) {
        gf::Rect r{px, board_.y + 24 + (i - 1) * 52, 38, 38};
        p.fill_rounded_rect(r, 19, peg_color(i));
        text(p, r.x + 12, r.y + 26, std::string(1, static_cast<char>('A' + i - 1)), 18,
             gf::Color::rgba(14, 28, 39));
    }
    text(p, 28, 122, "A code of four", 21, accent);
    text(p, 28, 162, "Choose a place, then", 13, ink);
    text(p, 28, 185, "a symbol A–F.", 13, ink);
    text(p, 28, 224, "Repeats are allowed.", 13, muted);
    text(p, 28, 272, "●  Exact position", 13, ink);
    text(p, 28, 300, "○  Elsewhere in code", 13, ink);
    text(p, 28, 348, "Feedback gives counts,", 13, muted);
    text(p, 28, 371, "not peg positions.", 13, muted);
    if (game.state.over) {
        std::string answer = "Code: ";
        for (int i = 0; i < 4; ++i)
            answer += std::string(1, static_cast<char>('A' + game.state.secret[i] - 1)) + " ";
        text(p, board_.x + 90, board_.y + board_.height - 7, answer, 20, accent);
    }
}
void PuzzleView::paint_switches(gf::Painter& p) {
    gf::Rect b = client_rectangle();
    double cx = b.width * .5, top = board_.y + board_.height * .53;
    double t = elapsed(), motion = animation_duration_ > 0 && t < animation_duration_ && !reduced_
                                       ? std::sin(t / animation_duration_ * 3.141592654)
                                       : 0;
    p.fill_radial_gradient(
        {cx - 250, 80, 500, 450}, {cx, 270}, {260, 230},
        std::array<gf::GradientStop, 2>{
            {{0, gf::Color::rgba(105, 180, 156, 75)}, {1, gf::Color::rgba(105, 180, 156, 0)}}});
    if (girl_.value)
        p.draw_image(girl_, {cx - 200, top - 295 - motion * 14, 400, 400});
    gf::Rect box{cx - 264, top, 528, 195};
    p.draw_box_shadow(box, 18, {0, 12}, 30, 0, gf::Color::rgba(0, 0, 0, 110));
    p.fill_linear_gradient(box, {box.x, box.y}, {box.x, box.y + box.height},
                           std::array<gf::GradientStop, 2>{{{0, gf::Color::rgba(167, 108, 77)},
                                                            {1, gf::Color::rgba(99, 61, 56)}}});
    p.stroke_rounded_rect(box, 15, gf::Color::rgba(224, 160, 107), 3);
    for (int i = 0; i < 7; ++i)
        p.draw_line({box.x + 5, box.y + 17 + i * 26}, {box.x + box.width - 5, box.y + 21 + i * 26},
                    gf::Color::rgba(231, 163, 109, 38), 1);
    p.fill_rounded_rect({cx - 247, top + 28, 494, 91}, 12, gf::Color::rgba(56, 44, 49));
    cells_.clear();
    for (int i = 0; i < 5; ++i) {
        gf::Rect r{cx - 222 + i * 96, top + 40, 60, 64};
        cells_.push_back(r);
        p.fill_rounded_rect(r, 10, gf::Color::rgba(23, 32, 40));
        bool on = game.state.grid[i];
        double lever = on ? -10 : 10;
        if (animation_duration_ > 0 && t < animation_duration_ && i == hover_ && !on)
            lever = 10 - 20 * motion;
        p.fill_rounded_rect({r.x + 13, r.y + 21 + lever, 34, 21}, 6,
                            on ? gf::Color::rgba(142, 229, 187) : gf::Color::rgba(237, 211, 177));
        text(p, r.x + 24, r.y + 91, std::to_string(i + 1), 17, gf::Color::rgba(255, 231, 197));
        if (game.state.marks[i]) {
            p.draw_line({r.x + 17, r.y - 9}, {r.x + 43, r.y - 23}, gf::Color::rgba(245, 152, 152),
                        2);
            p.draw_line({r.x + 43, r.y - 9}, {r.x + 17, r.y - 23}, gf::Color::rgba(245, 152, 152),
                        2);
        }
    }
    if (motion > 0 && hover_ >= 0 && hover_ < 5 && !game.state.grid[hover_]) {
        gf::Point hand{cx - 192 + hover_ * 96, top + 71};
        gf::Point shoulder{cx + 84, top - 37};
        gf::Point end{shoulder.x + (hand.x - shoulder.x) * motion,
                      shoulder.y + (hand.y - shoulder.y) * motion};
        gf::Point elbow{shoulder.x + (end.x - shoulder.x) * .48,
                         shoulder.y + (end.y - shoulder.y) * .68 + 13 * motion};
        p.draw_line(shoulder, elbow, gf::Color::rgba(76, 116, 96), 31);
        p.draw_line(shoulder, elbow, gf::Color::rgba(149, 186, 154), 27);
        p.fill_rounded_rect({elbow.x - 14, elbow.y - 14, 28, 28}, 14,
                            gf::Color::rgba(149, 186, 154));
        p.draw_line(elbow, end, gf::Color::rgba(209, 165, 145), 19);
        p.draw_line(elbow, end, gf::Color::rgba(250, 219, 193), 15);
        p.fill_rounded_rect({end.x - 12, end.y - 9, 24, 19}, 8,
                            gf::Color::rgba(252, 222, 193));
        for (int finger = 0; finger < 3; ++finger)
            p.draw_line({end.x - 6 + finger * 5.0, end.y + 3},
                        {end.x - 6 + finger * 5.0, end.y + 8},
                        gf::Color::rgba(197, 149, 134), 1);
    }
    text(p, 28, 121, "Her secret order", 20, accent);
    text(p, 28, 158, "Try switches 1–5.", 13, ink);
    text(p, 28, 196, "Correct: stays on.", 13, ink);
    text(p, 28, 223, "Wrong: she resets it.", 13, ink);
    text(p, 28, 270, "A crossed switch cannot", 13, muted);
    text(p, 28, 293, "be next at this step.", 13, muted);
    text(p, 28, 344, std::to_string(15 - game.state.moves) + " tries remain", 14, accent);
}
void PuzzleView::paint_atoms(gf::Painter& p) {
    cells_.clear();
    double cell = board_.width / 6, ox = board_.x + cell, oy = board_.y + cell;
    for (int i = 0; i < 16; ++i) {
        gf::Rect r{ox + i % 4 * cell, oy + i / 4 * cell, cell, cell};
        cells_.push_back(r);
        p.fill_rounded_rect({r.x + 3, r.y + 3, cell - 6, cell - 6}, 9, gf::Color::rgba(29, 49, 66));
        if (game.state.grid[i] || (game.state.over && game.state.secret[i])) {
            gf::Color c = game.state.over
                              ? game.state.secret[i] ? accent : gf::Color::rgba(229, 112, 124)
                              : gf::Color::rgba(229, 183, 105);
            p.fill_rounded_rect({r.x + cell * .27, r.y + cell * .27, cell * .46, cell * .46},
                                cell * .23, c);
        }
    }
    for (int port = 0; port < 16; ++port) {
        double x, y;
        if (port < 4) {
            x = ox + (port + .5) * cell;
            y = oy - cell * .5;
        } else if (port < 8) {
            x = ox + 4.5 * cell;
            y = oy + (port - 4 + .5) * cell;
        } else if (port < 12) {
            x = ox + (11 - port + .5) * cell;
            y = oy + 4.5 * cell;
        } else {
            x = ox - cell * .5;
            y = oy + (15 - port + .5) * cell;
        }
        gf::Rect r{x - 23, y - 23, 46, 46};
        cells_.push_back(r);
        p.fill_rounded_rect(r, 12,
                            game.state.aux[port] == -99 ? gf::Color::rgba(49, 70, 86)
                                                        : gf::Color::rgba(65, 114, 122));
        std::string label = game.state.aux[port] == -99  ? std::to_string(port + 1)
                            : game.state.aux[port] == -1 ? "A"
                            : game.state.aux[port] == -2 ? "R"
                                                         : std::to_string(game.state.aux[port] + 1);
        text(p, r.x + (label.size() == 1 ? 18 : 12), r.y + 29, label, 18, ink);
    }
    text(p, 28, 120, "Find three atoms", 21, accent);
    text(p, 28, 158, "Click an edge port", 13, ink);
    text(p, 28, 181, "to send a probe.", 13, ink);
    text(p, 28, 224, "A  Absorbed", 13, ink);
    text(p, 28, 252, "R  Reflected", 13, ink);
    text(p, 28, 280, "Number  Exit port", 13, ink);
    text(p, 28, 326, "Click squares to mark", 13, muted);
    text(p, 28, 349, "your three-atom guess.", 13, muted);
    text(p, 28, 400, "Help explains deflection.", 13, accent);
}
void PuzzleView::paint_solve(gf::Painter& p) {
    double cell = board_.width / 6;
    for (int i = 0; i < 36; ++i) {
        int value = game.state.grid[i], piece = value / 4, color = value % 4;
        gf::Rect r{board_.x + (i % 6) * cell, board_.y + (i / 6) * cell, cell, cell};
        if (!value) {
            p.fill_rect({r.x + 1, r.y + 1, cell - 2, cell - 2}, gf::Color::rgba(28, 46, 63));
            continue;
        }
        bool left = i % 6 > 0 && game.state.grid[i - 1] / 4 == piece,
             right = i % 6 < 5 && game.state.grid[i + 1] / 4 == piece,
             top = i >= 6 && game.state.grid[i - 6] / 4 == piece,
             bottom = i < 30 && game.state.grid[i + 6] / 4 == piece;
        gf::Rect tile{r.x + (left ? 0 : 2), r.y + (top ? 0 : 2),
                      cell - (left ? 0 : 2) - (right ? 0 : 2),
                      cell - (top ? 0 : 2) - (bottom ? 0 : 2)};
        p.fill_rect(tile,
                    color == 1 ? gf::Color::rgba(51, 147, 225) : gf::Color::rgba(251, 205, 78));
        gf::Color edge = piece == selection_ + 1 ? gf::Color::rgba(244, 242, 212)
                                                 : gf::Color::rgba(164, 189, 205);
        if (!left)
            p.draw_line({r.x + 2, r.y + 2}, {r.x + 2, r.y + cell - 2}, edge, 2);
        if (!right)
            p.draw_line({r.x + cell - 2, r.y + 2}, {r.x + cell - 2, r.y + cell - 2}, edge, 2);
        if (!top)
            p.draw_line({r.x + 2, r.y + 2}, {r.x + cell - 2, r.y + 2}, edge, 2);
        if (!bottom)
            p.draw_line({r.x + 2, r.y + cell - 2}, {r.x + cell - 2, r.y + cell - 2}, edge, 2);
    }
    if (hover_ >= 0 && !game.state.over) {
        std::vector<PieceCell> cells = game.piece_cells(selection_, rotation_, flip_);
        int minx = 10, miny = 10;
        for (PieceCell c : cells) {
            minx = std::min(minx, c.x);
            miny = std::min(miny, c.y);
        }
        bool valid = true;
        for (PieceCell c : cells) {
            int x = hover_ % 6 + c.x - minx, y = hover_ / 6 + c.y - miny;
            if (x >= 6 || y >= 6 ||
                (game.state.grid[y * 6 + x] && game.state.grid[y * 6 + x] / 4 != selection_ + 1))
                valid = false;
        }
        for (PieceCell c : cells) {
            int x = hover_ % 6 + c.x - minx, y = hover_ / 6 + c.y - miny;
            if (x >= 6 || y >= 6)
                continue;
            gf::Rect ghost{board_.x + x * cell + 3, board_.y + y * cell + 3, cell - 6, cell - 6};
            p.fill_rect(ghost, c.color == 1 ? gf::Color::rgba(80, 172, 239, 75)
                                            : gf::Color::rgba(249, 215, 116, 75));
            p.stroke_rect(
                ghost, valid ? gf::Color::rgba(155, 226, 188) : gf::Color::rgba(245, 134, 134), 2);
        }
    }
    text(p, 28, 121, "The target", 20, accent);
    p.fill_rounded_rect({23, 138, 154, 154}, 4, gf::Color::rgba(6, 22, 38));
    p.stroke_rounded_rect({23, 138, 154, 154}, 4, gf::Color::rgba(119, 150, 165), 1);
    for (int i = 0; i < 36; ++i)
        p.fill_rect({28 + (i % 6) * 24.0, 143 + (i / 6) * 24.0, 23, 23},
                    game.state.secret[i] == 1 ? gf::Color::rgba(51, 147, 225)
                                              : gf::Color::rgba(251, 205, 78));
    text(p, 28, 326, "Select a piece.", 13, ink);
    text(p, 28, 353, "R rotates. F flips.", 13, ink);
    text(p, 28, 380, "Click the frame to place.", 13, ink);
    text(p, 28, 420, "Right click a placed", 13, muted);
    text(p, 28, 443, "piece to lift it.", 13, muted);
    text(p, board_.x + board_.width + 27, board_.y - 11, "PIECES", 11, muted);
    cells_.clear();
    for (int piece = 0; piece < 12; ++piece) {
        double row_step = (board_.height - 110) / 6;
        double x = board_.x + board_.width + 26 + (piece % 2) * 95,
               y = board_.y + (piece / 2) * row_step;
        gf::Rect r{x, y, 84, row_step - 8};
        cells_.push_back(r);
        bool used = false;
        for (int i = 0; i < 36; ++i)
            used = used || game.state.grid[i] / 4 == piece + 1;
        p.fill_rounded_rect(
            r, 6, piece == selection_ ? gf::Color::rgba(70, 92, 109) : gf::Color::rgba(30, 44, 61));
        std::vector<PieceCell> shape = game.piece_cells(piece, piece == selection_ ? rotation_ : 0,
                                                        piece == selection_ && flip_);
        int minx = 10, miny = 10;
        for (PieceCell c : shape) {
            minx = std::min(minx, c.x);
            miny = std::min(miny, c.y);
        }
        int maxx = 0, maxy = 0;
        for (PieceCell c : shape) {
            maxx = std::max(maxx, c.x - minx);
            maxy = std::max(maxy, c.y - miny);
        }
        double tile =
                   std::min((maxx == 2 || maxy == 2) ? 15.0 : 19.0, (r.height - 20) / (maxy + 1)),
               origin = x + (84 - (maxx + 1) * tile) * .5;
        for (PieceCell c : shape)
            p.fill_rect(
                {origin + (c.x - minx) * tile, y + 5 + (c.y - miny) * tile, tile - 1, tile - 1},
                used           ? gf::Color::rgba(81, 97, 109)
                : c.color == 1 ? gf::Color::rgba(51, 147, 225)
                               : gf::Color::rgba(251, 205, 78));
        text(p, x + 7, y + r.height - 7, std::to_string(piece + 1), 11, muted);
        p.stroke_rounded_rect(r, 6,
                              piece == selection_ ? accent : gf::Color::rgba(101, 125, 143, 70), 1);
    }
    text(p, board_.x + board_.width + 29, board_.y + board_.height - 29,
         "Piece " + std::to_string(selection_ + 1), 14, accent);
}
void PuzzleView::paint_sticks(gf::Painter& p) {
    std::vector<Point2> hex = PuzzleGame::hex_cells();
    double unit = board_.width / 14.5, cx = board_.x + board_.width * .5,
           cy = board_.y + board_.height * .5;
    cells_.clear();
    for (int i = 0; i < 37; ++i) {
        double x = cx + unit * 1.7320508 * (hex[i].x + hex[i].y * .5),
               y = cy + unit * 1.5 * hex[i].y;
        gf::Rect r{x - unit * .8, y - unit * .8, unit * 1.6, unit * 1.6};
        cells_.push_back(r);
        if (hover_ >= 100 && hover_ < 121) {
            int axis = (hover_ - 100) / 7, line = (hover_ - 100) % 7 - 3;
            int coordinate = static_cast<int>(axis == 0   ? hex[i].x
                                              : axis == 1 ? hex[i].y
                                                          : -hex[i].x - hex[i].y);
            if (coordinate == line)
                for (int row = -static_cast<int>(unit * .88); row <= static_cast<int>(unit * .88);
                     ++row) {
                    double half = std::min(unit * .762, (unit * .88 - std::abs(row)) * 1.732);
                    p.draw_line({x - half, y + row}, {x + half, y + row},
                                gf::Color::rgba(130, 161, 109, 35), 1);
                }
        }
        for (int k = 0; k < 6; ++k) {
            double a = (k * 60 + 30) * 3.14159265 / 180, b = ((k + 1) * 60 + 30) * 3.14159265 / 180;
            p.draw_line({x + unit * .91 * std::cos(a), y + unit * .91 * std::sin(a)},
                        {x + unit * .91 * std::cos(b), y + unit * .91 * std::sin(b)},
                        gf::Color::rgba(103, 143, 143), 1.4);
        }
        int v = game.state.grid[i];
        if (v == 1) {
            p.fill_rounded_rect({x - unit * .36, y - unit * .30, unit * .72, unit * .62},
                                unit * .27, gf::Color::rgba(182, 191, 177));
            p.draw_line({x - unit * .18, y - unit * .13}, {x + unit * .12, y - unit * .19},
                        gf::Color::rgba(224, 231, 213), 2);
        } else if (v) {
            double angle = (v - 2) * 3.14159265 / 3;
            gf::Point a{x - std::cos(angle) * unit * .53, y - std::sin(angle) * unit * .53},
                b{x + std::cos(angle) * unit * .53, y + std::sin(angle) * unit * .53};
            if (v >= 5) {
                gf::Point previous = a;
                for (int k = 1; k <= 10; ++k) {
                    double t = k / 10.0;
                    gf::Point next{a.x + (b.x - a.x) * t -
                                       std::sin(angle) * std::sin(t * 3.14159265) * unit * .3,
                                   a.y + (b.y - a.y) * t +
                                       std::cos(angle) * std::sin(t * 3.14159265) * unit * .3};
                    p.draw_line(previous, next, gf::Color::rgba(215, 160, 100), 6);
                    previous = next;
                }
            } else
                p.draw_line(a, b, gf::Color::rgba(215, 160, 100), 6);
        }
    }
    for (int axis = 0; axis < 3; ++axis)
        for (int line = -3; line <= 3; ++line) {
            Point2 extreme{};
            bool first = true;
            for (Point2 c : hex) {
                int n = static_cast<int>(axis == 0 ? c.x : axis == 1 ? c.y : -c.x - c.y);
                if (n != line)
                    continue;
                Point2 q{cx + unit * 1.7320508 * (c.x + c.y * .5), cy + unit * 1.5 * c.y};
                if (first || (axis == 0   ? q.y < extreme.y
                              : axis == 1 ? q.x > extreme.x
                                          : q.x < extreme.x)) {
                    extreme = q;
                    first = false;
                }
            }
            Point2 endpoint = extreme;
            if (axis == 0) {
                extreme.x -= unit * .736;
                extreme.y -= unit * 1.275;
            } else if (axis == 1)
                extreme.x += unit * 1.30;
            else {
                extreme.x -= unit * .736;
                extreme.y += unit * 1.275;
            }
            clues_[axis * 7 + line + 3] = {extreme.x - 17, extreme.y - 11, 34, 22};
            bool highlighted = hover_ == 100 + axis * 7 + line + 3;
            p.draw_line({endpoint.x + (extreme.x - endpoint.x) * .68,
                         endpoint.y + (extreme.y - endpoint.y) * .68},
                        {endpoint.x + (extreme.x - endpoint.x) * .86,
                         endpoint.y + (extreme.y - endpoint.y) * .86},
                        highlighted ? gf::Color::rgba(213, 217, 145)
                                    : gf::Color::rgba(119, 145, 122),
                        highlighted ? 2 : 1);
            std::array<int, 2> target = game.hex_count(axis, line, true),
                               current = game.hex_count(axis, line, false);
            gf::Color color = current == target ? gf::Color::rgba(135, 225, 161)
                              : current[0] > target[0] || current[1] > target[1]
                                  ? gf::Color::rgba(240, 135, 132)
                                  : gf::Color::rgba(223, 207, 172);
            text(p, extreme.x - 8, extreme.y + 5,
                 std::to_string(target[0]) + "/" + std::to_string(target[1]), 12, color);
        }
    text(p, 28, 119, "Balance every line", 19, accent);
    text(p, 28, 157, "Perimeter: sticks / stones", 13, ink);
    text(p, 28, 191, "Every straight line", 13, muted);
    text(p, 28, 214, "must match its clue.", 13, muted);
    text(p, 28, 233, "Hover a clue to follow its line.", 11, accent);
    for (int value = 1; value <= 7; ++value) {
        int i = value - 1;
        gf::Rect tile{27 + (i % 2) * 99.0, 245 + (i / 2) * 66.0, 88, 56};
        cells_.push_back(tile);
        p.fill_rounded_rect(
            tile, 6, value == palette_ ? gf::Color::rgba(70, 93, 72) : gf::Color::rgba(36, 56, 47));
        p.stroke_rounded_rect(
            tile, 6,
            value == palette_ ? gf::Color::rgba(219, 197, 134) : gf::Color::rgba(105, 129, 108), 1);
        text(p, tile.x + 7, tile.y + 45, std::to_string(value), 11, muted);
        double x = tile.x + 47, y = tile.y + 27;
        if (value == 1) {
            p.fill_rounded_rect({x - 15, y - 11, 30, 23}, 11, gf::Color::rgba(183, 194, 177));
            p.draw_line({x - 7, y - 4}, {x + 5, y - 6}, gf::Color::rgba(229, 233, 219), 2);
        } else {
            double angle = (value - 2) * 3.14159265 / 3;
            gf::Point previous{};
            for (int k = 0; k <= 16; ++k) {
                double t = k / 16.0, u = (t - .5) * 38,
                       v = value >= 5 ? std::sin(t * 3.14159265) * 12 : 0;
                gf::Point q{x + u * std::cos(angle) - v * std::sin(angle),
                            y + u * std::sin(angle) + v * std::cos(angle)};
                if (k)
                    p.draw_line(previous, q, gf::Color::rgba(221, 171, 109), 5);
                previous = q;
            }
        }
    }
    text(p, 28, 536, "Click to place. Right click to clear.", 12, ink);
    text(p, 28, 558, "Keys 1–7 choose a shape.", 12, muted);
}
void PuzzleView::paint_help(gf::Painter& p) {
    std::vector<std::string> lines;
    if (game.kind == PuzzleKind::gems)
        lines = {"Drag between neighboring gems to match three or more of one color.",
                 "An invalid swap finishes, then returns both gems to their places.",
                 "Four in a line makes a colored bomb. Matching it clears a 3 × 3 area.",
                 "A T or L match makes a star. Matching it clears its row and column.",
                 "Five in a line makes a hypercube: swap it with a color to clear that color.",
                 "Blasts trigger other specials. Cascades refill the board from above.",
                 "Additional colors arrive as you progress. No available swap ends the run."};
    else if (game.kind == PuzzleKind::cube)
        lines = {"Connect all six colored pairs on the surface of the cube.",
                 "Click a colored endpoint square and trace through neighboring squares.",
                 "Paths cannot share a square. Empty squares are allowed.",
                 "Move around the cube to turn it; hover its surface to steady it.",
                 "Right drag rotates freely. Release a path, turn, then click its tail.",
                 "Click an original endpoint to redraw that pair; trace backward to erase.",
                 "Every generated puzzle includes a replay-verified solution."};
    else if (game.kind == PuzzleKind::untangle)
        lines = {"Drag points until no two unrelated edges cross or touch.",
                 "Connected edges may meet at their shared point.",
                 "Keep points separated; piling them together does not solve the puzzle.",
                 "Each graph was built from a planar solution before it was scrambled.",
                 "You can move one point at a time, or pull a cluster outward."};
    else if (game.kind == PuzzleKind::pegs)
        lines = {"Find the four-symbol code in ten guesses. Six symbols A–F are available.",
                 "The secret may repeat a symbol. Feedback counts each occurrence once.",
                 "Filled feedback: right symbol in the right position.",
                 "Ring feedback: right symbol, but in a different position.",
                 "Choose a place, then click a colored letter, or type A–F / 1–6.",
                 "Left / right selects a place. Enter submits the completed row.",
                 "The code remains fixed throughout the game."};
    else if (game.kind == PuzzleKind::switches)
        lines = {"Five switches have a secret order. Each switch appears exactly once.",
                 "A correct switch stays on. The girl resets an incorrect switch.",
                 "A crossed switch is ruled out for the current next position.",
                 "After a correct choice the crosses clear for the new position.",
                 "You have fifteen tries: 5 + 4 + 3 + 2 + 1 is sufficient in the worst case.",
                 "Click a switch or type 1–5. Already solved / ruled-out switches cost nothing.",
                 "Animation carries the same information as the visible switches and crosses."};
    else if (game.kind == PuzzleKind::atom)
        lines = {"Three atoms are hidden in a 4 × 4 chamber. Click ports to launch rays.",
                 "An atom directly ahead absorbs the ray (A), before any deflection.",
                 "An atom diagonally ahead bends the ray 90° away from that atom.",
                 "Atoms on both forward diagonals reflect it (R). A boundary deflection",
                 "also reflects immediately. A number labels the port where a ray emerges.",
                 "Click squares to mark exactly three atoms, then Submit your deduction.",
                 "The generator rejects boards with identical complete probe signatures."};
    else if (game.kind == PuzzleKind::solve)
        lines = {"Reproduce the blue / yellow target using all twelve geometric pieces.",
                 "Straight and L pieces each carry three individually colored squares.",
                 "Choose a piece on the right. Rotate / R turns it; Flip / F mirrors it.",
                 "Click the large frame to place the piece with its top-left bounds there.",
                 "Pieces cannot overlap. Right click a placed piece to lift it.",
                 "The target is generated from an actual tiling, so a solution always exists.",
                 "An alternative arrangement with the same colors is also a solution."};
    else
        lines = {"Fill all 37 hexagons with a stick or stone.",
                 "Each perimeter clue reads number of sticks / number of stones.",
                 "The three straight-line directions all impose constraints at once.",
                 "Choose 1 for stone; 2–4 for straight sticks; 5–7 for curved sticks.",
                 "Different stick shapes have the same count. Right click clears a hex.",
                 "Green clues are satisfied; red clues exceed a required count.",
                 "Any complete arrangement satisfying every clue wins."};
    for (std::size_t i = 0; i < lines.size(); ++i)
        text(p, popup_.x + 28, popup_.y + 94 + i * 42, lines[i], 14, ink);
}
void PuzzleView::on_paint(gf::Painter& p, gf::Rect) {
    gf::Rect b = client_rectangle();
    const gf::Color backgrounds[] = {gf::Color::rgba(23, 28, 47), gf::Color::rgba(24, 45, 43),
                                     gf::Color::rgba(20, 44, 51), gf::Color::rgba(17, 37, 58),
                                     gf::Color::rgba(39, 34, 39), gf::Color::rgba(31, 55, 56),
                                     gf::Color::rgba(22, 36, 51), gf::Color::rgba(35, 46, 39)};
    p.fill_rect(b, backgrounds[static_cast<int>(game.kind)]);
    if (game.kind != PuzzleKind::cube) {
        double heights[] = {350, 0, 225, 347, 319, 288, 390, 495};
        gf::Rect notes{14, 86, 224, heights[static_cast<int>(game.kind)]};
        p.fill_rounded_rect(notes, 8, gf::Color::rgba(8, 22, 33, 110));
        p.stroke_rounded_rect(notes, 8, gf::Color::rgba(126, 151, 158, 45), 1);
        p.draw_line({28, 133}, {222, 133}, gf::Color::rgba(145, 174, 174, 65), 1);
        if (game.kind == PuzzleKind::untangle || game.kind == PuzzleKind::solve) {
            gf::Rect mat{board_.x - 10, board_.y - 10, board_.width + 20, board_.height + 20};
            p.draw_box_shadow(mat, 13, {0, 5}, 20, 0, gf::Color::rgba(0, 8, 19, 110));
            p.fill_rounded_rect(mat, 13, gf::Color::rgba(13, 30, 43));
            p.stroke_rounded_rect(mat, 13, gf::Color::rgba(92, 121, 133, 90), 1);
            p.draw_inset_box_shadow(mat, 13, {0, 3}, 8, 0, gf::Color::rgba(0, 5, 16, 100));
        }
    }
    if (game.kind == PuzzleKind::cube && nature_.value) {
        p.draw_image(nature_, b);
        p.fill_rect(b, gf::Color::rgba(8, 24, 24, 56));
        p.fill_rounded_rect({15, 83, 235, 176}, 12, gf::Color::rgba(15, 38, 42, 190));
        text(p, 28, 114, "Let each color find home", 17, ink);
        text(p, 28, 145, "Trace from a colored square.", 13, ink);
        text(p, 28, 174, "Move around the cube to turn.", 13, ink);
        text(p, 28, 203, "Right drag for a faster orbit.", 13, ink);
        text(p, 28, 232, "Help: continue across faces.", 13, ink);
        if (image_.value)
            p.draw_image(image_, board_);
    } else if (game.kind == PuzzleKind::gems)
        paint_gems(p);
    else if (game.kind == PuzzleKind::untangle)
        paint_untangle(p);
    else if (game.kind == PuzzleKind::pegs)
        paint_pegs(p);
    else if (game.kind == PuzzleKind::switches)
        paint_switches(p);
    else if (game.kind == PuzzleKind::atom)
        paint_atoms(p);
    else if (game.kind == PuzzleKind::solve)
        paint_solve(p);
    else if (game.kind == PuzzleKind::sticks)
        paint_sticks(p);
    paint_heading(p, {0, 0, b.width, 68}, puzzle_title(game.kind), static_cast<int>(game.kind) + 2);
    p.fill_rect({0, b.height - 43, b.width, 43}, gf::Color::rgba(17, 31, 45, 225));
    text(p, 28, b.height - 16, game.message, 13, ink);
    if (!panel_)
        return;
    p.fill_rect(b, gf::Color::rgba(4, 12, 26, 175));
    paint_dialog(p, popup_, panel_ == 1 ? "How to play" : "TOP SCORES",
                 game_accent(static_cast<int>(game.kind) + 2));
    if (panel_ == 1) {
        paint_help(p);
        return;
    }
    text(p, popup_.x + 28, popup_.y + 82,
         std::string(puzzle_title(game.kind)) + " · " +
             (game.kind == PuzzleKind::gems ? "Highest points" : "Fewest moves") +
             (game.state.over ? " · Result: " + std::to_string(game.result()) : ""),
         15, accent);
    if (!game.qualifies())
        text(p, popup_.x + 28, popup_.y + 132,
             game.recorded                        ? "Your name is saved."
             : game.state.over && !game.state.won ? "A fresh puzzle is waiting when you are ready."
                                                  : "Complete a game to enter your name.",
             14, ink);
    for (std::size_t i = 0; i < game.scores.size(); ++i) {
        text(p, popup_.x + 28, popup_.y + 178 + i * 27, std::to_string(i + 1), 16, accent);
        text(p, popup_.x + 75, popup_.y + 178 + i * 27, game.scores[i].name, 16, ink);
        text(p, popup_.x + 544, popup_.y + 178 + i * 27, std::to_string(game.scores[i].value), 16,
             accent);
    }
}
void PuzzleView::panel(int kind) {
    panel_ = kind;
    for (int i = 0; i < 6; ++i)
        (*buttons_[i]).set_enabled(!kind);
    (*buttons_[6]).set_visible(kind != 0);
    (*buttons_[7]).set_visible(kind == 2 && game.qualifies());
    (*buttons_[8]).set_visible(kind == 2 && game.state.over);
    (*name_).set_visible(kind == 2 && game.qualifies());
    if (kind == 2)
        (*name_).set_text(game.player_name);
    if (attached_window())
        static_cast<void>(
            (*attached_window()).request_focus(kind ? buttons_[6] : shared_from_this()));
    invalidate(gf::Dirty::paint);
}
void PuzzleView::persist() {
    if (game.kind == PuzzleKind::pegs)
        for (int i = 0; i < 4; ++i)
            game.state.marks[i] = guess_[i];
    if (!game.save(path()))
        game.message = "Your game is in memory; the local save could not be written.";
}
void PuzzleView::changed(const std::string& effect) {
    persist();
    if (game.state.over) {
        if (game.state.won)
            sound_play("stinger_" + std::string(game.qualifies() ? "topscore_" : "win_") +
                           (game.kind == PuzzleKind::cube ? "nature_cube" : puzzle_slug(game.kind)),
                       sound_);
        else
            sound_play(game.kind == PuzzleKind::pegs ? "four_pegs_out_of_turns"
                                                     : "atom_probe_check_wrong",
                       sound_);
        if (animation_duration_ <= 0)
            panel(2);
    } else if (!effect.empty())
        sound_play(effect, sound_);
    render();
    invalidate(gf::Dirty::paint);
}
void PuzzleView::new_game() {
    game.deal(
        static_cast<std::uint32_t>(std::chrono::system_clock::now().time_since_epoch().count()));
    animation_duration_ = 0;
    drag_ = -1;
    tracing_ = false;
    guess_.fill(0);
    selection_ = 0;
    rotation_ = 0;
    flip_ = false;
    set_pointer_capture(false);
    panel(0);
    persist();
    music_play(game.kind == PuzzleKind::cube ? "nature_cube" : puzzle_slug(game.kind), music_);
    sound_play("ui_new_game", sound_);
    render();
}
void PuzzleView::action(gf::ButtonBase& button) {
    std::string id(button.stable_id().value());
    int index = std::stoi(id.substr(id.rfind('.') + 1));
    if (index == 0 || index == 8)
        new_game();
    if (index == 1)
        panel(1);
    if (index == 2)
        panel(2);
    if (index == 3) {
        if (game.kind == PuzzleKind::pegs && game.guess_pegs(guess_)) {
            guess_.fill(0);
            selection_ = 0;
            changed("four_pegs_submit");
        } else if (game.kind == PuzzleKind::atom && game.submit_atoms())
            changed(game.state.won ? "atom_probe_check_correct" : "atom_probe_check_wrong");
    }
    if (index == 4) {
        rotation_ = (rotation_ + 1) % 4;
        sound_play("puzzle_solve_rotate", sound_);
    }
    if (index == 5) {
        flip_ = !flip_;
        sound_play("puzzle_solve_flip", sound_);
    }
    if (index == 6)
        panel(0);
    if (index == 7 && game.record(std::string((*name_).text()))) {
        persist();
        sound_play("ui_name_confirm", sound_);
        panel(2);
    }
    if (!panel_ && attached_window())
        static_cast<void>((*attached_window()).request_focus(shared_from_this()));
    invalidate(gf::Dirty::paint);
}
int PuzzleView::hit(gf::Point p) const {
    if (game.kind == PuzzleKind::gems) {
        if (!in_rect(board_, p))
            return -1;
        int x = static_cast<int>((p.x - board_.x) * 8 / board_.width),
            y = static_cast<int>((p.y - board_.y) * 8 / board_.height);
        return y * 8 + x;
    }
    if (game.kind == PuzzleKind::cube) {
        if (!in_rect(board_, p) || raster_.ids.empty())
            return -1;
        int x = std::clamp(static_cast<int>((p.x - board_.x) / board_.width * raster_.width), 0,
                           raster_.width - 1),
            y = std::clamp(static_cast<int>((p.y - board_.y) / board_.height * raster_.height), 0,
                           raster_.height - 1);
        return raster_.ids[y * raster_.width + x];
    }
    if (game.kind == PuzzleKind::untangle) {
        for (int i = 0; i < 12; ++i)
            if (std::hypot(p.x - board_.x - game.state.nodes[i].x * board_.width,
                           p.y - board_.y - game.state.nodes[i].y * board_.height) < 22)
                return i;
        return -1;
    }
    for (std::size_t i = 0; i < cells_.size(); ++i)
        if (in_rect(cells_[i], p))
            return static_cast<int>(i);
    return -1;
}
void PuzzleView::tick() {
    if (!effectively_visible()) {
        if (timer_)
            (*timer_).stop();
        return;
    }
    bool moving = false;
    if (game.kind == PuzzleKind::gems && animation_duration_ > 0 && !invalid_swap_ &&
        elapsed() >= .23 && !game.state.over) {
        int step = static_cast<int>((elapsed() - .23) / .24);
        if (step != cascade_step_ && step % 2 == 0 &&
            step + 1 < static_cast<int>(game.cascade_frames.size())) {
            int depth = std::min(5, step / 2 + 1);
            std::string effect = "gems_match_0" + std::to_string(depth);
            const std::array<int, 96>& before = game.cascade_frames[step];
            const std::array<int, 96>& after = game.cascade_frames[step + 1];
            for (int i = 0; i < 64; ++i) {
                if (before[i] >= 16 && before[i] != after[i])
                    effect = before[i] == 48 ? "gems_hypercube"
                             : before[i] >= 32 ? "gems_star_line" : "gems_bomb";
            }
            sound_play(effect, sound_);
        }
        cascade_step_ = step;
    }
    if (animation_duration_ > 0) {
        if (elapsed() >= animation_duration_) {
            animation_duration_ = 0;
            if (game.state.over)
                panel(2);
        } else
            moving = true;
    }
    if (game.kind == PuzzleKind::cube) {
        double dx = target_yaw_ - yaw_, dy = target_pitch_ - pitch_;
        if (std::abs(dx) + std::abs(dy) > .0005) {
            yaw_ += dx * .23;
            pitch_ += dy * .23;
            moving = true;
        }
    }
    if (game.kind == PuzzleKind::gems && !reduced_ && !panel_)
        moving = true;
    render();
    invalidate(board_);
    if (game.kind == PuzzleKind::switches)
        invalidate(gf::Dirty::paint);
    if (!moving && timer_)
        (*timer_).stop();
}
void PuzzleView::on_pointer(gf::PointerEvent& e) {
    const gf::Point local_position = point_from_window(e.position);
    if (panel_)
        return;
    int cell = hit(local_position);
    if (e.action == gf::PointerAction::move) {
        if (game.kind == PuzzleKind::sticks) {
            int next = -1;
            for (int i = 0; i < 21; ++i)
                if (in_rect(clues_[i], local_position))
                    next = 100 + i;
            if (next != hover_) {
                hover_ = next;
                invalidate(gf::Dirty::paint);
            }
        }
        if (game.kind == PuzzleKind::solve) {
            int next = -1;
            if (in_rect(board_, local_position))
                next = static_cast<int>((local_position.y - board_.y) * 6 / board_.height) * 6 +
                       static_cast<int>((local_position.x - board_.x) * 6 / board_.width);
            if (next != hover_) {
                hover_ = next;
                invalidate(board_);
            }
        }

        if (game.kind == PuzzleKind::gems) {
            if (hover_ != cell) {
                hover_ = cell;
                if (reduced_) {
                    render();
                    invalidate(board_);
                }
            }
        }
        if (game.kind == PuzzleKind::untangle && drag_ >= 0) {
            drag_position_ = {
                std::clamp((local_position.x - board_.x) / board_.width, .035, .965),
                std::clamp((local_position.y - board_.y) / board_.height, .035, .965)};
            invalidate(board_);
        }
        if (game.kind == PuzzleKind::cube) {
            double dx = local_position.x - last_pointer_.x, dy = local_position.y - last_pointer_.y;
            if (std::abs(dx) < 150 && std::abs(dy) < 150 && !tracing_ && (orbit_ || cell < 0)) {
                target_yaw_ += dx * (orbit_ ? .009 : .0025);
                target_pitch_ = std::clamp(target_pitch_ + dy * (orbit_ ? .009 : .0025), -2.8, 2.8);
                if (timer_)
                    (*timer_).start();
            }
            if (!tracing_ && !orbit_ && cell >= 0) {
                target_yaw_ = yaw_;
                target_pitch_ = pitch_;
            }
            if (tracing_ && cell >= 0 && game.cube_extend(cell))
                changed("nature_cube_trace");
            hover_ = cell;
            last_pointer_ = local_position;
            render();
            invalidate(board_);
        }
        return;
    }
    if (e.action == gf::PointerAction::down) {
        if (attached_window())
            static_cast<void>((*attached_window()).request_focus(shared_from_this()));
        if (game.state.over)
            return;
        if (game.kind == PuzzleKind::cube) {
            last_pointer_ = local_position;
            orbit_ = e.button == gf::PointerButton::secondary;
            if (orbit_) {
                set_pointer_capture(true);
                return;
            }
            if (cell >= 0) {
                bool started = false;
                for (int pair = 0; pair < 6; ++pair)
                    if (!game.state.paths[pair].empty() && game.state.paths[pair].back() == cell &&
                        !game.cube_pair(cell)) {
                        game.state.stage = pair + 1;
                        started = true;
                    }
                if (!started)
                    started = game.cube_start(cell);
                if (started) {
                    tracing_ = true;
                    set_pointer_capture(true);
                    target_yaw_ = yaw_;
                    target_pitch_ = pitch_;
                    changed("nature_cube_connect");
                }
            }
            return;
        }
        if (animation_duration_ > 0)
            return;
        if (game.kind == PuzzleKind::gems && cell >= 0) {
            drag_ = cell;
            set_pointer_capture(true);
        } else if (game.kind == PuzzleKind::untangle && cell >= 0) {
            drag_ = cell;
            drag_position_ = game.state.nodes[cell];
            set_pointer_capture(true);
            sound_play("untangle_grab", sound_);
        } else if (game.kind == PuzzleKind::pegs) {
            if (cell >= 0 && cell < 4)
                selection_ = cell;
            double px = board_.x + board_.width + 52;
            for (int i = 1; i <= 6; ++i)
                if (in_rect({px, board_.y + 24 + (i - 1) * 52, 38, 38}, local_position)) {
                    guess_[selection_] = i;
                    selection_ = (selection_ + 1) % 4;
                    sound_play("four_pegs_place", sound_);
                    persist();
                }
        } else if (game.kind == PuzzleKind::switches && cell >= 0 && game.flip_switch(cell)) {
            hover_ = cell;
            animation_start_ = gf::FrameClock::now();
            animation_duration_ = reduced_ ? 0 : .65;
            if (timer_)
                (*timer_).start();
            changed(game.state.grid[cell] ? "switchbox_switch_on" : "switchbox_reset");
        } else if (game.kind == PuzzleKind::atom && cell >= 0) {
            if (cell < 16 && game.mark_atom(cell))
                changed("atom_probe_mark");
            else if (cell >= 16 && game.probe(cell - 16))
                changed("atom_probe_fire");
        } else if (game.kind == PuzzleKind::solve) {
            if (cell >= 0) {
                selection_ = cell;
                rotation_ = 0;
                flip_ = false;
                sound_play("puzzle_solve_pickup", sound_);
                drag_ = cell;
                set_pointer_capture(true);
            } else if (in_rect(board_, local_position)) {
                int x = static_cast<int>((local_position.x - board_.x) * 6 / board_.width),
                    y = static_cast<int>((local_position.y - board_.y) * 6 / board_.height);
                if (e.button == gf::PointerButton::secondary) {
                    int piece = game.state.grid[y * 6 + x] / 4 - 1;
                    if (game.remove_piece(piece)) {
                        selection_ = piece;
                        changed("puzzle_solve_pickup");
                    }
                } else if (game.place_piece(selection_, x, y, rotation_, flip_))
                    changed("puzzle_solve_place");
                else
                    sound_play("puzzle_solve_no_fit", sound_);
            }
        } else if (game.kind == PuzzleKind::sticks) {
            if (cell >= 0 &&
                game.set_stick(cell, e.button == gf::PointerButton::secondary ? 0 : palette_))
                changed(palette_ == 1 ? "sticks_stones_stone_place" : "sticks_stones_stick_place");
            if (cell >= 37 && cell < 44)
                palette_ = cell - 36;
        }
        invalidate(gf::Dirty::paint);
        e.handled = true;
    }
    if (e.action == gf::PointerAction::up) {
        set_pointer_capture(false);
        if (game.kind == PuzzleKind::solve && drag_ >= 0) {
            drag_ = -1;
            if (in_rect(board_, local_position)) {
                int x = static_cast<int>((local_position.x - board_.x) * 6 / board_.width),
                    y = static_cast<int>((local_position.y - board_.y) * 6 / board_.height);
                if (game.place_piece(selection_, x, y, rotation_, flip_))
                    changed("puzzle_solve_place");
                else
                    sound_play("puzzle_solve_no_fit", sound_);
            }
        }
        if (game.kind == PuzzleKind::cube) {
            tracing_ = false;
            orbit_ = false;
            persist();
        }
        if (game.kind == PuzzleKind::untangle && drag_ >= 0) {
            game.move_node(drag_, drag_position_);
            drag_ = -1;
            changed("untangle_release");
        }
        if (game.kind == PuzzleKind::gems && drag_ >= 0) {
            int from = drag_;
            drag_ = -1;
            if (cell >= 0 && std::abs(from / 8 - cell / 8) + std::abs(from % 8 - cell % 8) == 1) {
                before_swap_ = game.state.grid;
                cascade_step_ = -1;
                swap_a_ = from;
                swap_b_ = cell;
                invalid_swap_ = !game.gem_swap(from, cell);
                animation_start_ = gf::FrameClock::now();
                animation_duration_ = reduced_ ? 0
                                      : invalid_swap_
                                          ? .46
                                          : .23 + .24 * (game.cascade_frames.size() - 1);
                if (timer_)
                    (*timer_).start();
                changed(invalid_swap_ ? "gems_swap_return" : "gems_swap");
            }
        }
        e.handled = true;
    }
}
void PuzzleView::on_key_bubble(gf::KeyEvent& e) {
    on_key(e);
}
void PuzzleView::on_key(gf::KeyEvent& e) {
    if (e.handled || e.action != gf::KeyAction::down)
        return;
    if (e.physical_key == gf::PhysicalKey::escape) {
        panel(0);
        e.handled = true;
        return;
    }
    if (panel_)
        return;
    if (e.physical_key == gf::PhysicalKey::r && game.kind == PuzzleKind::solve)
        rotation_ = (rotation_ + 1) % 4;
    else if (e.physical_key == gf::PhysicalKey::f && game.kind == PuzzleKind::solve)
        flip_ = !flip_;
    else if (e.physical_key == gf::PhysicalKey::left && game.kind == PuzzleKind::pegs)
        selection_ = (selection_ + 3) % 4;
    else if (e.physical_key == gf::PhysicalKey::right && game.kind == PuzzleKind::pegs)
        selection_ = (selection_ + 1) % 4;
    else if (e.physical_key == gf::PhysicalKey::enter &&
             (game.kind == PuzzleKind::pegs || game.kind == PuzzleKind::atom))
        action(*buttons_[3]);
    else
        return;
    invalidate(gf::Dirty::paint);
    e.handled = true;
}
void PuzzleView::on_text_input(gf::TextInputEvent& e) {
    if (panel_ || game.state.over || animation_duration_ > 0 || e.text_utf8.size() != 1)
        return;
    char c = e.text_utf8[0];
    int value = c >= '1' && c <= '7'   ? c - '0'
                : c >= 'a' && c <= 'f' ? c - 'a' + 1
                : c >= 'A' && c <= 'F' ? c - 'A' + 1
                                       : 0;
    if (game.kind == PuzzleKind::pegs && value >= 1 && value <= 6) {
        guess_[selection_] = value;
        selection_ = (selection_ + 1) % 4;
        sound_play("four_pegs_place", sound_);
        persist();
    } else if (game.kind == PuzzleKind::sticks && value >= 1 && value <= 7)
        palette_ = value;
    else if (game.kind == PuzzleKind::switches && value >= 1 && value <= 5 &&
             game.flip_switch(value - 1)) {
        hover_ = value - 1;
        animation_start_ = gf::FrameClock::now();
        animation_duration_ = reduced_ ? 0 : .65;
        if (timer_)
            (*timer_).start();
        changed(game.state.grid[value - 1] ? "switchbox_switch_on" : "switchbox_reset");
    } else
        return;
    e.handled = true;
    invalidate(gf::Dirty::paint);
}
} // namespace games
