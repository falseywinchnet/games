#include "collection.hpp"
#include "audio.hpp"
#include "gui_forms/window.hpp"
#include <fstream>
namespace games {
Collection::Collection(gf::StableId id) : Control(std::move(id)) {
    std::ifstream saved(cabinet_path().parent_path() / "current-game.txt");
    int active = 0;
    saved >> active;
    if (saved && active >= 0 && active < 9)
        active_ = active;
    else
        choosing_ = true;
    if (!std::filesystem::exists(cabinet_path())) {
        Cabinet initial;
        initial.games[0].deal(Kind::solitaire, 1);
        initial.started[0] = true;
        save_cabinet(cabinet_path(), initial);
    }
    set_theme_override(games_theme());
}
void Collection::initialize_control_tree() {
    cards_ = gf::make_control<Table>(gf::StableId("collection.cards"));
    sudoku_ = gf::make_control<SudokuView>(gf::StableId("collection.sudoku"));
    add_child(cards_);
    add_child(sudoku_);
    for (int i = 0; i < 8; ++i) {
        puzzles_[i] = gf::make_control<PuzzleView>(
            gf::StableId("collection.puzzle." + std::to_string(i)), static_cast<PuzzleKind>(i));
        add_child(puzzles_[i]);
    }
    library_ = gf::make_control<LibrarySurface>(gf::StableId("collection.library"));
    add_child(library_);
    for (int i = 0; i < 9; ++i) {
        tiles_[i] = gf::make_control<GameTile>(gf::StableId("collection." + std::to_string(i)), i);
        (*library_).add_child(tiles_[i]);
        subscriptions_.push_back(
            (*tiles_[i])
                .clicked()
                .subscribe(
                    *this,
                    gf::Delegate<gf::ButtonBase&>::bind<Collection, &Collection::choose>(*this)));
    }
    const char* labels[] = {"Collection", "Music on", "Sound on", "Full motion"};
    for (int i = 0; i < 4; ++i) {
        controls_[i] = gf::make_control<GameButton>(
            gf::StableId("collection.command." + std::to_string(i)), labels[i]);
        add_child(controls_[i]);
        subscriptions_.push_back(
            (*controls_[i])
                .clicked()
                .subscribe(
                    *this,
                    gf::Delegate<gf::ButtonBase&>::bind<Collection, &Collection::command>(*this)));
    }
    preferences();
    visibility();
}
void Collection::visibility() {
    (*cards_).set_visible(!choosing_ && active_ == 0);
    (*sudoku_).set_visible(!choosing_ && active_ == 1);
    for (int i = 0; i < 8; ++i)
        (*puzzles_[i]).set_visible(!choosing_ && active_ == i + 2);
    (*library_).set_visible(choosing_);
    (*controls_[0]).set_selected(choosing_);
}
void Collection::arrange(gf::Rect b) {
    arrange_self(b);
    gf::Rect content{0, 52, b.width, b.height - 52};
    set_child_layout(cards_, content);
    set_child_layout(sudoku_, content);
    for (int i = 0; i < 8; ++i)
        set_child_layout(puzzles_[i], content);
    set_child_layout(library_, content);
    set_child_layout(controls_[0], {153, 9, 132, 33});
    for (int i = 1; i < 4; ++i)
        set_child_layout(controls_[i], {b.width - 367 + (i - 1) * 119.0, 9, 108, 33});
}
void Collection::on_paint(gf::Painter& p, gf::Rect) {
    gf::Rect b = client_rectangle();
    const gf::GradientStop stops[] = {{0, gf::Color::rgba(50, 68, 83)},
                                      {1, gf::Color::rgba(22, 39, 55)}};
    p.fill_linear_gradient({0, 0, b.width, 52}, {0, 0}, {0, 52}, stops);
    p.draw_text_utf8({25, 34}, "GAMES", {gf::FontRole::content, 22, 700, false, 2.4},
                     gf::Color::rgba(231, 221, 184));
    p.draw_line({134, 12}, {134, 39}, gf::Color::rgba(8, 20, 34), 1);
    p.draw_line({135, 12}, {135, 39}, gf::Color::rgba(119, 144, 158, 80), 1);
    p.draw_line({0, 51}, {b.width, 51}, gf::Color::rgba(4, 15, 26), 1);
    if (!choosing_) {
        const char* names[] = {"The card room", "Sudoku",         "Gems",      "Nature Cube",
                               "Untangle",      "Atom Probe",     "Four Pegs", "Switchbox",
                               "Puzzle Solve",  "Sticks & Stones"};
        p.draw_text_utf8({306, 32}, names[active_], {gf::FontRole::content, 14, 400, false},
                         gf::Color::rgba(166, 190, 202));
    }
}
void Collection::preferences() {
    Cabinet cabinet;
    if (!load_cabinet(cabinet_path(), cabinet))
        return;
    (*controls_[1]).set_text(cabinet.music ? "Music on" : "Music off");
    (*controls_[2]).set_text(cabinet.sound ? "Sound on" : "Sound off");
    (*controls_[3]).set_text(cabinet.reduced ? "Quiet motion" : "Full motion");
}
void Collection::activate() {
    preferences();
    if (choosing_) {
        Cabinet cabinet;
        load_cabinet(cabinet_path(), cabinet);
        music_play("menu", cabinet.music);
        return;
    }
    if (active_ == 0)
        (*cards_).activate();
    else if (active_ == 1)
        (*sudoku_).activate();
    else
        (*puzzles_[active_ - 2]).activate();
}
void Collection::choose(gf::ButtonBase& button) {
    active_ = std::stoi(std::string(button.stable_id().value().substr(11)));
    choosing_ = false;
    visibility();
    std::filesystem::path path = cabinet_path().parent_path() / "current-game.txt",
                          temporary = path;
    temporary += ".tmp";
    std::error_code error;
    std::filesystem::create_directories(path.parent_path(), error);
    std::ofstream saved(temporary);
    saved << active_ << '\n';
    saved.close();
    if (saved)
        std::filesystem::rename(temporary, path, error);
    activate();
    invalidate(gf::Dirty::paint);
}
void Collection::command(gf::ButtonBase& button) {
    std::string id(button.stable_id().value());
    int index = std::stoi(id.substr(id.rfind('.') + 1));
    if (index == 0) {
        choosing_ = !choosing_;
        visibility();
        activate();
        invalidate(gf::Dirty::paint);
        return;
    }
    Cabinet cabinet;
    if (!load_cabinet(cabinet_path(), cabinet))
        return;
    if (index == 1)
        cabinet.music = !cabinet.music;
    if (index == 2)
        cabinet.sound = !cabinet.sound;
    if (index == 3)
        cabinet.reduced = !cabinet.reduced;
    if (save_cabinet(cabinet_path(), cabinet)) {
        (*cards_).reload_preferences();
        preferences();
        activate();
    }
}
} // namespace games
