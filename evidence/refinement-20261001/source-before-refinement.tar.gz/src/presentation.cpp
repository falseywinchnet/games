#include "presentation.hpp"
#include <algorithm>
#include <array>
#include <cmath>
namespace games {
static gf::Color mix(gf::Color a, gf::Color b, double t) {
    return gf::Color::rgba(static_cast<unsigned char>(a.red * (1 - t) + b.red * t),
                           static_cast<unsigned char>(a.green * (1 - t) + b.green * t),
                           static_cast<unsigned char>(a.blue * (1 - t) + b.blue * t),
                           static_cast<unsigned char>(a.alpha * (1 - t) + b.alpha * t));
}
static void gradient(gf::Painter& p, gf::Rect r, gf::Color a, gf::Color b) {
    const gf::GradientStop stops[] = {{0, a}, {1, b}};
    p.fill_linear_gradient(r, {r.x, r.y}, {r.x, r.y + r.height}, stops);
}
gf::Color game_accent(int game) {
    const gf::Color colors[] = {gf::Color::rgba(213, 184, 113), gf::Color::rgba(125, 191, 238),
                                gf::Color::rgba(191, 145, 231), gf::Color::rgba(148, 205, 171),
                                gf::Color::rgba(119, 212, 221), gf::Color::rgba(129, 182, 225),
                                gf::Color::rgba(228, 172, 121), gf::Color::rgba(167, 219, 181),
                                gf::Color::rgba(243, 203, 100), gf::Color::rgba(192, 198, 142)};
    return colors[std::clamp(game, 0, 9)];
}
GameButton::GameButton(gf::StableId id, std::string label)
    : Button(std::move(id), std::move(label)) {
    set_font({gf::FontRole::content, 14, 600, false, .1});
    set_use_mnemonic(false);
    set_content_padding({9, 2, 9, 2});
}
void GameButton::set_skin(ButtonSkin skin) {
    skin_ = skin;
    invalidate(gf::Dirty::paint);
}
void GameButton::on_paint(gf::Painter& p, gf::Rect) {
    gf::Rect b = client_rectangle();
    gf::Rect r{1, 1, b.width - 2, b.height - 3};
    bool down = pressed_visual(), hot = hovered_visual(), chosen = selected(),
         light = skin_ == ButtonSkin::ivory || skin_ == ButtonSkin::blue;
    gf::Color top = light ? gf::Color::rgba(247, 246, 235) : gf::Color::rgba(56, 79, 99),
              bottom = light ? gf::Color::rgba(212, 218, 202) : gf::Color::rgba(30, 49, 69),
              border = light ? gf::Color::rgba(119, 145, 136) : gf::Color::rgba(82, 107, 126),
              ink = light ? gf::Color::rgba(39, 65, 60) : gf::Color::rgba(226, 236, 242);
    if (skin_ == ButtonSkin::blue) {
        top = gf::Color::rgba(244, 251, 255);
        bottom = gf::Color::rgba(197, 223, 241);
        border = gf::Color::rgba(113, 157, 191);
        ink = gf::Color::rgba(31, 81, 120);
    }
    if (skin_ == ButtonSkin::mint) {
        top = gf::Color::rgba(77, 109, 102);
        bottom = gf::Color::rgba(39, 68, 66);
        border = gf::Color::rgba(125, 161, 137);
    }
    if (chosen) {
        top = gf::Color::rgba(235, 212, 153);
        bottom = gf::Color::rgba(189, 150, 82);
        border = gf::Color::rgba(130, 100, 49);
        ink = gf::Color::rgba(45, 49, 49);
    }
    if (hot) {
        top = mix(top, gf::Color::rgba(245, 246, 229), .12);
        border = mix(border, gf::Color::rgba(181, 220, 225), .55);
    }
    if (down)
        std::swap(top, bottom);
    if (!enabled()) {
        top = mix(top, bottom, .5);
        ink = mix(ink, bottom, .55);
        border = mix(border, bottom, .4);
    }
    if (!down)
        p.draw_box_shadow(r, 5, {0, 2}, 2, 0, gf::Color::rgba(0, 8, 17, 70));
    p.save();
    p.clip_rounded_rect(r, 5);
    gradient(p, r, top, bottom);
    p.restore();
    p.stroke_rounded_rect(r, 5, border, 1);
    p.draw_line({r.x + 5, r.y + 1}, {r.x + r.width - 5, r.y + 1},
                gf::Color::rgba(255, 255, 255,
                                down    ? 20
                                : light ? 195
                                        : 53),
                1);
    p.draw_line({r.x + 4, r.y + r.height - 1}, {r.x + r.width - 4, r.y + r.height - 1},
                gf::Color::rgba(6, 20, 35, light ? 30 : 90), 1);
    paint_button_content(p, r, text(), ink, {down ? 1.0 : 0, down ? 1.0 : 0}, chosen);
    if (focus_cue_visible())
        p.stroke_rounded_rect(
            {4, 4, b.width - 8, b.height - 9}, 3,
            light ? gf::Color::rgba(45, 103, 131) : gf::Color::rgba(170, 216, 233), 1);
}
std::shared_ptr<const gf::Theme> games_theme(ButtonSkin skin) {
    gf::ThemeDefinition theme = gf::windows_professional_theme_definition();
    theme.id = "games-authored-" + std::to_string(static_cast<int>(skin));
    bool light = skin == ButtonSkin::blue || skin == ButtonSkin::ivory;
    theme.structure.typography.control = {gf::FontRole::content, 14, 400, false};
    theme.structure.typography.field = {gf::FontRole::content, 16, 400, false};
    theme.compatibility.text = light ? gf::Color::rgba(35, 63, 82) : gf::Color::rgba(229, 235, 241);
    theme.compatibility.border =
        light ? gf::Color::rgba(119, 156, 181) : gf::Color::rgba(87, 117, 138);
    for (std::size_t i = 0; i < gf::control_surface_state_count; ++i) {
        gf::ControlVisualRecipe& editor =
            theme.roles[static_cast<std::size_t>(gf::ControlVisualRole::editor)].ordinary[i];
        editor.material.fills = {gf::MaterialFillLayer::solid(light ? gf::Color::rgba(252, 253, 250)
                                                                    : gf::Color::rgba(12, 27, 43))};
        editor.material.corner_radius = 4;
        editor.material.border = gf::MaterialBorder{
            light ? gf::Color::rgba(115, 153, 184) : gf::Color::rgba(104, 147, 171), 1};
        editor.text = light ? gf::Color::rgba(26, 59, 83) : gf::Color::rgba(239, 240, 222);
        editor.focus_ring = gf::Color::rgba(140, 192, 222);
    }
    return gf::Theme::create(std::move(theme));
}
static void polygon(gf::Painter& p, const std::vector<gf::Point>& points, gf::Color color) {
    double ymin = 100000, ymax = -100000;
    for (gf::Point q : points) {
        ymin = std::min(ymin, q.y);
        ymax = std::max(ymax, q.y);
    }
    for (double y = std::ceil(ymin); y < ymax; ++y) {
        std::vector<double> intersections;
        for (std::size_t i = 0; i < points.size(); ++i) {
            gf::Point a = points[i], b = points[(i + 1) % points.size()];
            if ((a.y <= y && b.y > y) || (b.y <= y && a.y > y))
                intersections.push_back(a.x + (y - a.y) * (b.x - a.x) / (b.y - a.y));
        }
        std::sort(intersections.begin(), intersections.end());
        for (std::size_t i = 1; i < intersections.size(); i += 2)
            p.draw_line({intersections[i - 1], y}, {intersections[i], y}, color, 1);
    }
}
void paint_emblem(gf::Painter& p, gf::Rect r, int game) {
    double x = r.x, y = r.y, w = r.width, h = r.height;
    gf::Color accent = game_accent(game);
    gf::Color white = gf::Color::rgba(235, 241, 244);
    if (game == 0) {
        p.fill_rounded_rect({x + w * .12, y + h * .2, w * .48, h * .68}, 4,
                            gf::Color::rgba(132, 154, 171));
        p.fill_rounded_rect({x + w * .31, y + h * .08, w * .5, h * .68}, 4,
                            gf::Color::rgba(248, 243, 221));
        p.draw_text_utf8({x + w * .42, y + h * .57}, "A",
                         {gf::FontRole::content, h * .40, 700, false},
                         gf::Color::rgba(147, 47, 70));
    } else if (game == 1) {
        p.fill_rounded_rect({x + w * .12, y + h * .1, w * .77, h * .77}, 4,
                            gf::Color::rgba(223, 235, 244));
        for (int i = 1; i < 3; ++i) {
            p.draw_line({x + w * (.12 + i * .257), y + h * .1},
                        {x + w * (.12 + i * .257), y + h * .87}, gf::Color::rgba(108, 158, 192), 1);
            p.draw_line({x + w * .12, y + h * (.1 + i * .257)},
                        {x + w * .89, y + h * (.1 + i * .257)}, gf::Color::rgba(108, 158, 192), 1);
        }
        p.draw_text_utf8({x + w * .20, y + h * .56}, "7",
                         {gf::FontRole::content, h * .25, 700, false},
                         gf::Color::rgba(41, 95, 147));
        p.draw_text_utf8({x + w * .70, y + h * .80}, "3",
                         {gf::FontRole::content, h * .25, 700, false},
                         gf::Color::rgba(41, 95, 147));
    } else if (game == 2) {
        polygon(p,
                {{x + w * .13, y + h * .37},
                 {x + w * .3, y + h * .13},
                 {x + w * .71, y + h * .13},
                 {x + w * .89, y + h * .37},
                 {x + w * .5, y + h * .9}},
                gf::Color::rgba(133, 80, 181));
        polygon(p,
                {{x + w * .13, y + h * .37}, {x + w * .89, y + h * .37}, {x + w * .5, y + h * .9}},
                accent);
        polygon(p,
                {{x + w * .34, y + h * .37}, {x + w * .65, y + h * .37}, {x + w * .5, y + h * .9}},
                gf::Color::rgba(226, 181, 255));
        p.draw_line({x + w * .3, y + h * .15}, {x + w * .71, y + h * .15},
                    gf::Color::rgba(255, 233, 253), 2);
    } else if (game == 3) {
        polygon(p,
                {{x + w * .15, y + h * .28},
                 {x + w * .5, y + h * .10},
                 {x + w * .85, y + h * .28},
                 {x + w * .5, y + h * .47}},
                gf::Color::rgba(203, 230, 210));
        polygon(p,
                {{x + w * .15, y + h * .28},
                 {x + w * .5, y + h * .47},
                 {x + w * .5, y + h * .88},
                 {x + w * .15, y + h * .68}},
                gf::Color::rgba(118, 167, 152));
        polygon(p,
                {{x + w * .5, y + h * .47},
                 {x + w * .85, y + h * .28},
                 {x + w * .85, y + h * .68},
                 {x + w * .5, y + h * .88}},
                gf::Color::rgba(155, 199, 185));
    } else if (game == 4) {
        gf::Point points[] = {{x + w * .18, y + h * .23},
                              {x + w * .82, y + h * .24},
                              {x + w * .32, y + h * .80},
                              {x + w * .77, y + h * .75}};
        for (int i = 0; i < 4; ++i)
            p.draw_line(points[i], points[(i + 1) % 4], accent, 2);
        p.draw_line(points[0], points[3], accent, 2);
        for (gf::Point q : points)
            p.fill_rounded_rect({q.x - 4, q.y - 4, 8, 8}, 4, white);
    } else if (game == 5) {
        for (int direction = 0; direction < 3; ++direction) {
            gf::Point previous{};
            for (int k = 0; k <= 40; ++k) {
                double a = k * 6.2831853 / 40, u = std::cos(a) * w * .4, v = std::sin(a) * h * .16,
                       turn = direction * 1.0471976;
                gf::Point q{x + w * .5 + u * std::cos(turn) - v * std::sin(turn),
                            y + h * .5 + u * std::sin(turn) + v * std::cos(turn)};
                if (k)
                    p.draw_line(previous, q, accent, 1.2);
                previous = q;
            }
        }
        p.fill_rounded_rect({x + w * .43, y + h * .43, w * .14, h * .14}, w * .07, white);
    } else if (game == 6) {
        const gf::Color colors[] = {gf::Color::rgba(224, 115, 112), gf::Color::rgba(100, 184, 224),
                                    gf::Color::rgba(231, 187, 98), gf::Color::rgba(141, 203, 161)};
        for (int i = 0; i < 4; ++i)
            p.fill_rounded_rect(
                {x + w * (.14 + (i % 2) * .4), y + h * (.14 + (i / 2) * .4), w * .29, h * .29},
                w * .145, colors[i]);
    } else if (game == 7) {
        p.fill_rounded_rect({x + w * .1, y + h * .3, w * .8, h * .5}, 5,
                            gf::Color::rgba(165, 113, 85));
        p.stroke_rounded_rect({x + w * .1, y + h * .3, w * .8, h * .5}, 5,
                              gf::Color::rgba(224, 179, 122), 1);
        for (int i = 0; i < 3; ++i) {
            p.fill_rounded_rect({x + w * (.22 + i * .23), y + h * .43, w * .13, h * .20}, 2,
                                gf::Color::rgba(31, 54, 58));
            p.fill_rounded_rect(
                {x + w * (.235 + i * .23), y + h * (i == 0 ? .44 : .54), w * .10, h * .06}, 1,
                accent);
        }
    } else if (game == 8) {
        for (int i = 0; i < 9; ++i)
            p.fill_rounded_rect(
                {x + w * (.12 + (i % 3) * .26), y + h * (.12 + (i / 3) * .26), w * .235, h * .235},
                2,
                (i == 0 || i == 1 || i == 3 || i == 8) ? gf::Color::rgba(247, 205, 103)
                                                       : gf::Color::rgba(83, 162, 215));
    } else {
        p.fill_rounded_rect({x + w * .15, y + h * .46, w * .35, h * .25}, h * .11,
                            gf::Color::rgba(186, 198, 177));
        p.draw_line({x + w * .50, y + h * .72}, {x + w * .82, y + h * .20},
                    gf::Color::rgba(217, 174, 109), 5);
        p.draw_line({x + w * .5, y + h * .29}, {x + w * .8, y + h * .75},
                    gf::Color::rgba(175, 137, 85), 4);
    }
}
GameTile::GameTile(gf::StableId id, int game) : Button(std::move(id)), game_(game) {
    const char* titles[] = {"Card tables",  "Sudoku",         "Gems",      "Nature Cube",
                            "Untangle",     "Atom Probe",     "Four Pegs", "Switchbox",
                            "Puzzle Solve", "Sticks & Stones"};
    set_text(titles[game]);
    set_accessible_name(titles[game]);
    set_use_mnemonic(false);
}
void GameTile::on_paint(gf::Painter& p, gf::Rect) {
    gf::Rect b = client_rectangle(), r{2, 2, b.width - 4, b.height - 5};
    gf::Color accent = game_accent(game_),
              top = hovered_visual() ? gf::Color::rgba(51, 75, 94) : gf::Color::rgba(40, 58, 76),
              bottom = gf::Color::rgba(23, 40, 56);
    if (pressed_visual())
        std::swap(top, bottom);
    p.draw_box_shadow(r, 9, {0, 3}, 6, 0, gf::Color::rgba(1, 9, 20, 100));
    p.save();
    p.clip_rounded_rect(r, 9);
    gradient(p, r, top, bottom);
    p.restore();
    p.stroke_rounded_rect(r, 9, hovered_visual() ? accent : gf::Color::rgba(71, 91, 110), 1);
    p.draw_line({r.x + 10, r.y + 1}, {r.x + r.width - 10, r.y + 1},
                gf::Color::rgba(211, 231, 237, 37), 1);
    double offset = std::max(0.0, (b.height - 165) * .5);
    paint_emblem(p, {b.width * .5 - 31, 19 + offset, 62, 62}, game_);
    gf::FontSpec title{gf::FontRole::control, b.width < 190 ? 18.0 : 20.0, 600, false, .12};
    gf::Size size = p.measure_text_utf8(text(), title);
    p.draw_text_utf8({(b.width - size.width) * .5, 104 + offset}, text(), title,
                     gf::Color::rgba(235, 241, 242));
    const char* subtitles[] = {"Four classic card games",    "A quiet logic puzzle",
                               "Match, sparkle & cascade",   "Connect across six faces",
                               "Clear every crossing",       "Hidden-atom deduction",
                               "Crack the four-symbol code", "Her little secret order",
                               "Rotate, flip & reconstruct", "A garden of line clues"};
    gf::FontSpec small{gf::FontRole::content, 13, 400, false};
    gf::Size sub = p.measure_text_utf8(subtitles[game_], small);
    p.draw_text_utf8({(b.width - sub.width) * .5, 128 + offset}, subtitles[game_], small,
                     gf::Color::rgba(154, 178, 192));
    p.draw_line({b.width * .5 - 17, 145 + offset}, {b.width * .5 + 17, 145 + offset}, accent, 2);
    if (focus_cue_visible())
        p.stroke_rounded_rect({6, 6, b.width - 12, b.height - 13}, 6, accent, 1.5);
}
LibrarySurface::LibrarySurface(gf::StableId id) : Control(std::move(id)) {}
void LibrarySurface::arrange(gf::Rect b) {
    arrange_self(b);
    double width = (b.width - 132) / 5, height = std::min(232.0, (b.height - 178) / 2),
           top = 116 + (b.height - 178 - height * 2) / 2;
    int i = 0;
    for (const std::shared_ptr<gf::Control>& tile : children()) {
        set_child_layout(
            tile, {36 + (i % 5) * (width + 15), top + (i / 5) * (height + 17), width, height});
        ++i;
    }
}
void LibrarySurface::on_paint(gf::Painter& p, gf::Rect) {
    gf::Rect b = client_rectangle();
    gradient(p, b, gf::Color::rgba(25, 43, 61), gf::Color::rgba(11, 26, 40));
    p.draw_text_utf8({36, 53}, "Your game collection", {gf::FontRole::control, 30, 600, false, .2},
                     gf::Color::rgba(235, 232, 209));
    p.draw_text_utf8({38, 82}, "Pick up where you left off, or begin something new.",
                     {gf::FontRole::content, 16, 400, false}, gf::Color::rgba(164, 188, 203));
    p.draw_line({36, 103}, {b.width - 36, 103}, gf::Color::rgba(80, 103, 121), 1);
}
void paint_heading(gf::Painter& p, gf::Rect b, const std::string& title, int game) {
    gradient(p, b, gf::Color::rgba(34, 54, 73, 247), gf::Color::rgba(20, 36, 52, 247));
    p.draw_line({b.x, b.y + b.height - 1}, {b.x + b.width, b.y + b.height - 1},
                gf::Color::rgba(75, 96, 114), 1);
    paint_emblem(p, {b.x + 24, b.y + 10, 43, 43}, game);
    p.draw_text_utf8({b.x + 82, b.y + 41}, title, {gf::FontRole::control, 26, 600, false, .15},
                     gf::Color::rgba(238, 239, 226));
    p.draw_line({b.x + 82, b.y + 53}, {b.x + 122, b.y + 53}, game_accent(game), 2);
}
void paint_instrument(gf::Painter& p, gf::Rect r, const std::string& label, gf::Color accent) {
    p.fill_rounded_rect(r, 7, gf::Color::rgba(13, 29, 43, 150));
    p.stroke_rounded_rect(r, 7, gf::Color::rgba(100, 125, 137, 75), 1);
    p.draw_line({r.x + 14, r.y + 38}, {r.x + r.width - 14, r.y + 38},
                gf::Color::rgba(93, 118, 133, 100), 1);
    p.draw_text_utf8({r.x + 15, r.y + 25}, label, {gf::FontRole::content, 11, 700, false, 1.2},
                     accent);
}
void paint_dialog(gf::Painter& p, gf::Rect r, const std::string& title, gf::Color accent) {
    p.draw_box_shadow(r, 10, {0, 12}, 30, 0, gf::Color::rgba(0, 4, 12, 160));
    p.fill_rounded_rect(r, 10, gf::Color::rgba(25, 42, 61));
    p.save();
    p.clip_rounded_rect(r, 10);
    gradient(p, {r.x, r.y, r.width, 61}, gf::Color::rgba(57, 79, 97), gf::Color::rgba(31, 51, 72));
    p.restore();
    p.stroke_rounded_rect(r, 10, gf::Color::rgba(118, 142, 154), 1);
    p.draw_line({r.x + 1, r.y + 61}, {r.x + r.width - 1, r.y + 61}, gf::Color::rgba(15, 30, 47), 1);
    p.draw_text_utf8({r.x + 26, r.y + 41}, title, {gf::FontRole::control, 25, 600, false, .65},
                     gf::Color::rgba(240, 234, 209));
    p.draw_line({r.x + 27, r.y + 53}, {r.x + 71, r.y + 53}, accent, 2);
}
} // namespace games
